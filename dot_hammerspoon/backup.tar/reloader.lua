local reloadOnChange = function(paths, _flags)
  local basename = function(str) return string.gsub(str, "(.*/)([^/].+)", "%2") end
  local endsWith = function(str, ext) return str:match(".*%." .. ext) end


  for i, path in pairs(paths) do
    if endsWith(basename(path), 'lua') then
      hs.reload()
    end
  end
end

Pathwatcher = hs.pathwatcher.new(os.getenv("HOME") .. "/.hammerspoon", reloadOnChange)
Pathwatcher:start()
