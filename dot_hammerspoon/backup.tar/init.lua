local initialize = function()
  require 'config'
  require 'logger'
  require 'spoons'
  LoadSpoons({
    "EmmyLua",
    "ModalMgr",
    "WindowHalfsAndThirds",
  })

  require 'reloader'
  require 'index'
end



local status, err = pcall(initialize)
if status then
  hs.alert.show("Hammerspoon Configuration reloaded")
else
  hs.alert.show("ERROR reloading config")
  print(err)
end
