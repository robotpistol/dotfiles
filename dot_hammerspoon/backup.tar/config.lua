hs.ipc.cliInstall("/opt/homebrew/bin")
require('hs.ipc')

hs.autoLaunch(true)
hs.automaticallyCheckForUpdates(true)
hs.consoleOnTop(false)
hs.dockIcon(false)
hs.menuIcon(true)
hs.uploadCrashData(true)

hs.window.animationDuration = 0
